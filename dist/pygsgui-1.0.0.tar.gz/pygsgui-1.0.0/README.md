# pygsgui
This is a package that helps you build a GUI very easily when you want to make a game using pygame.